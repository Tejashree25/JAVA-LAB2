package com.cg.lesson4.pkg2;

import com.cg.lession4.pkg1.A;

public class Main extends A{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main a =new Main();
		System.out.println(a.protVar);
		System.out.println(a.pubVar);

		a.publicMethod();
		a.protectedMethod();
	

	}

}
