package com.cg.lesson4.pkg2;

import com.cg.lession4.pkg1.A;

public class B extends A{
	public void accessMod() 
	{
		A a=new A();
		System.out.println(a.pubVar);
		a.publicMethod();
	}

}
