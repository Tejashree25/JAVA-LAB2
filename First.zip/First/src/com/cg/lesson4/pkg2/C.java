package com.cg.lesson4.pkg2;

import com.cg.lession4.pkg1.A;

public class C extends A{
		C c= new C();
	
		
		
}
