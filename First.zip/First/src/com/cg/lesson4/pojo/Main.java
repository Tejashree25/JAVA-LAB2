package com.cg.lesson4.pojo;

public class Main {
	public static void main()
	{
		Employee e1 = new Employee(101,"Teju",8798.78);
		System.out.println(e1);
	}
}
