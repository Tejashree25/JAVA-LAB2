package com.cg.lesson_5.scannerd;

import java.util.Scanner;

public class Delimit {
	public static void main(String[] args) {
		String str="1.8,2.2,3.5,4,5,6,7,8";
		Scanner sc=new Scanner(str).useDelimiter(",");
		while(sc.hasNextInt())
		{
			int i=sc.nextInt();
			System.out.println(i);
		}
		while(sc.hasNextDouble())
		{
			double i=sc.nextDouble();
			System.out.println(i);
		}
		
	}

}
