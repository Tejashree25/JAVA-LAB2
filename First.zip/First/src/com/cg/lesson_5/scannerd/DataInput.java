package com.cg.lesson_5.scannerd;

import java.util.Scanner;

public class DataInput {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter id");
		int id=sc.nextInt();
		System.out.println("Enter Name");
		String a=sc.nextLine();
		a=sc.nextLine();
		System.out.println("Enter Salary");
		double d=sc.nextDouble();
		System.out.println("enter any character");
		char ch=sc.next().charAt(0);
		
		System.out.println("id :"+id);
		System.out.println("Name : "+a);
		System.out.println("salary :" +d);
		
		if(ch=='y')
			System.out.println("BYE");
		else
			System.out.println("HI");
	}

}
