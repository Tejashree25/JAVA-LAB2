package com.cg.lession4.pkg1;

public class A {
	public int pubVar=100;
	protected int protVar=200;
	private int priVar=300;
	int defVar=400;
	
	private void privateMethod()
	{
		System.out.println("private variable " +priVar);
	}
	protected void protectedMethod()
	{
		
		System.out.println("protected variable " +protVar);
		
	}
	public void publicMethod()
	{
		
		System.out.println("public variable " +pubVar);
		
	}
	void defaultMethod()
	{
	
		System.out.println("default variable " +defVar);
	}
}
