package com.cg.lesson4_var;

public class Main {

	public static void main(String[] args) {
		VarType v=new VarType();
		System.out.println("instance variable " + v.insVar);
		System.out.println("Static variable "+ v.staticVar);
		v.show();
	}

}
