package com.cg.lesson4_var;

public class VarType {
	public int insVar=	100;
	public static int staticVar=200;
	public void show()
	{
		int ivar=300;
		System.out.println("local variable ="+ivar);
	}
}
