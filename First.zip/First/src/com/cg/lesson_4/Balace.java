package com.cg.lesson_4;

public class Balace {
	String name;
	double bal;
	public Balace(String name, double bal) {
		super();
		this.name = name;
		this.bal = bal;
	}
	public void show()
	{
		if(bal>0)
		{
			System.out.println(name + "Rs. " + bal);
		}
	}
	public static void main(String[] args) {
		Balace b=new Balace("abc",4.34);
		b.show();
	}
			
}

