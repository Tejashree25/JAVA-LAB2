package com.cg.lesson_4;

public class Account {

	public static void main(String[] args) {
		Balace b=new Balace("Teju", 79000.90);
		b.show();

	}

}
