package com.cg.funda;

public class SwitchDemo {

	public static void main(String[] args) {
		int i=3;
		switch (i) {
		case 1:
			System.out.println("ONE");
			break;
		case 2:
			System.out.println("TWO");

		default:
			System.out.println("DEFAULT");
			break;
		}
	}

}
