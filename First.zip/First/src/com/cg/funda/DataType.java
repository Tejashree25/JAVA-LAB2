package com.cg.funda;

public class DataType {

	public static void main(String[] args) {
		boolean flag=true;
		System.out.println("boolean flag="+flag);
		
		char ch='A';
		System.out.println("char ch="+ch);
		
		byte b=12;
		System.out.println("Byte b="+b);
		
		short c=1;
		System.out.println("Short c="+c);
		
		float d=4.5f;
		System.out.println("floating d="+d);
		
		double e=34.98;
		System.out.println("double ="+ e);
		
		long g=687998;
		System.out.println("long ="+ g);

	}

}
