package com.cg.funda;

public class WhileDemo {
	public static void main(String[] args) {
		int i=1;
		while(i<11)
		{
			System.out.println(i);
			i++;
		}
		System.out.println("i= "+i);
		i=1;
		do {
			System.out.println(i);
			i++;
		}while(i<11);
		System.out.println(i);
		for(i=0;i<11;i++)
		{
			System.out.print(i+" ");
			
		}
	}

}
