package com.cg.funda;

public class TypeConversion {

	public static void main(String[] args) {
		int a=25;
		double d=a;
		System.out.println("a = "+a+"  d = "+d);
		
		double d1=25.25;
		int a1=(int)d1;
		System.out.println("d1= "+d1+" a1= "+ a1 );

	}

}
