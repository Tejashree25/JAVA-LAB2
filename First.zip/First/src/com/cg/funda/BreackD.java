package com.cg.funda;

public class BreackD {
 public static void main(String[] args) {
	int i=1;
	System.out.println("before loop");
	while(i<10){
		System.out.println(i);
		if(i==5)
			break;
		i++;
	}
	System.out.println("after loop");
}
}
