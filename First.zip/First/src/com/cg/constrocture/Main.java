package com.cg.constrocture;

public class Main {

	public static void main(String[] args) {
		Employee e=new Employee();
		Employee e1=new Employee(1,"Teju",5789);
		Employee e2=new Employee(e1);
		e.show();
		e1.show();
		e2.show();
		

	}

}
