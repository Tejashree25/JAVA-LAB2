package com.cg.constrocture;

public class Employee {
	public int id;
	public String name;
	public double salary;
	public Employee() {
		this.id=0;
		this.name=null;
		this.salary=0;
	}
	 Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public Employee(Employee e) {
		super();
		this.id = e.id;
		this.name = e.name;
		this.salary = e.salary;
	}
	public void show()
	{
		System.out.println(id +" "+name+" "+salary);
	}
	
}
