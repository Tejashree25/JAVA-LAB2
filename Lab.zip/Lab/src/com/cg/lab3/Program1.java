/*3.1: Create a method which can perform a particular String operation based on the user�s choice. 
 * The method should accept the String object and the user�s choice and return the output of the operation.
 * Tejashree Mahajan
 * 
 * */

package com.cg.lab3;


import java.util.Scanner;

public class Program1 {
	public static void main(String[] args) {
		char a;
		do {
		System.out.println("Enter String");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		System.out.println("***Menu***\n1.Add the String to itself\n 2.Replace odd positions with #\n 3.Remove duplicate characters in the String \n 4.Change odd characters to upper case");
		int choice=sc.nextInt();
		switch (choice) {
		case 1:
			String str2=str+str;
			System.out.println(str2);
			break;
		case 2:
			for(int i=0;i<str.length();i=i+2)
			{
				str=str.substring(0, i)+'#'+str.substring(i + 1);
	        }
			System.out.println(str);
			break;
		case 3:
			String str1=new String();
			for (int i = 0; i < str.length(); i++)  
	        { 
	            char c = str.charAt(i); 
	              
	            if (str1.indexOf(c) < 0) 
	            { 
	                str1 += c; 
	            } 
	        } 
			System.out.println(str1); 
			break;
		case 4:
			for(int i=0;i<str.length();i=i+2)
			{
				str=str.substring(0, i)+str.substring(i,i+1).toUpperCase()+str.substring(i + 1);
	        }
			System.out.println(str);
			break;
		default:
			break;
		}
		System.out.println("Do you want to continue(Y/N)");
		a=sc.next().charAt(0);
		}while(a=='Y');
	}
	

}

/*OUTPUT
 * Enter String
Tejashree
***Menu***
1.Add the String to itself
 2.Replace odd positions with #
 3.Remove duplicate characters in the String 
 4.Change odd characters to upper case
1
TejashreeTejashree
Do you want to continue(Y/N)
Y
Enter String
Tejashree
***Menu***
1.Add the String to itself
 2.Replace odd positions with #
 3.Remove duplicate characters in the String 
 4.Change odd characters to upper case
2
#e#a#h#e#
Do you want to continue(Y/N)
Y
Enter String
Tejashree
***Menu***
1.Add the String to itself
 2.Replace odd positions with #
 3.Remove duplicate characters in the String 
 4.Change odd characters to upper case
3
Tejashr
Do you want to continue(Y/N)
Y
Enter String
Tejashree
***Menu***
1.Add the String to itself
 2.Replace odd positions with #
 3.Remove duplicate characters in the String 
 4.Change odd characters to upper case
4
TeJaShReE
Do you want to continue(Y/N)
N
*/
