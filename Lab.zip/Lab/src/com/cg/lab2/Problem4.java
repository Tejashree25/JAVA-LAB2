package com.cg.lab2;

public class Problem4 {
	public String FirstName;
	public String Lastname;
	public char gender;
	public String phone;
	public Problem4()
	{
		this.FirstName = "Tejashree";
		this.Lastname = "Mahajan";
		this.gender = 'F';
		this.phone="888888888";
	}
	public Problem4(String firstName, String lastname, char gender, String phone) {
		super();
		FirstName = firstName;
		Lastname = lastname;
		this.gender = gender;
		this.phone = phone;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void show()
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("First Name:"+ FirstName);
		System.out.println("Last Name: "+ Lastname);
		System.out.println("Gender:"+ gender);
		System.out.println("Phone number:"+ phone);
	}
	
}
