package com.cg.lab2;

import java.util.Scanner;

enum Gender {
M,F
}
public class Problem5 {
	public String FirstName;
	public String Lastname;
	public String phone;
	public Gender g;
	public Problem5(String firstName, String lastname, String phone) {
		super();
		FirstName = firstName;
		Lastname = lastname;
		this.phone = phone;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setGender()
	{
		System.out.println("Enter Gender(M/F)");
		Scanner sc= new Scanner(System.in);
		String gender=sc.next();
		
		g=Gender.valueOf(gender);
			
	}
	public Gender getGender()
	{
		return g;
	}
	public void show()
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("First Name:"+ FirstName);
		System.out.println("Last Name: "+ Lastname);
		System.out.println("Gender:"+ g);
		System.out.println("Phone number:"+ phone);
	}

}
