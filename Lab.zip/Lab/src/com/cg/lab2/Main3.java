package com.cg.lab2;
/*Create default and parameterized constructor for Person class.
 * Tejashree Mahajan
 * */
public class Main3 {
	public static void main(String[] args) {
		Problem3 p=new Problem3();
		Problem3 p1=new Problem3("Tejashree","Mahajan",'F');
		p.show();
		p1.show();
	}
}
