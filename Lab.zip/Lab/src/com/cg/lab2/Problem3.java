package com.cg.lab2;

public class Problem3 {
	public String FirstName;
	public String Lastname;
	public char gender;
	public Problem3()
	{
		this.FirstName = "Tejashree";
		this.Lastname = "Mahajan";
		this.gender = 'F';
	}
	public Problem3(String firstName, String lastname, char gender) {
		super();
		FirstName = firstName;
		Lastname = lastname;
		this.gender = gender;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public void show()
	{
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("First Name:"+ FirstName);
		System.out.println("Last Name: "+ Lastname);
		System.out.println("Gender:"+ gender);
	}
	
}
