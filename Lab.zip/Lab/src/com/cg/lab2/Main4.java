package com.cg.lab2;
/*
 * Modify Lab assignment 2.3 to accept phone number of a person. Create a newmethod to implement the same and also define method for displaying persondetails.
 * Tejashree Mahajan
 * */
public class Main4 {

	public static void main(String[] args) {
		Problem4 p=new Problem4();
		Problem4 p1=new Problem4("Tejashree","Mahajan",'F',"8888888888");
		p.show();
		p1.show();

	}

}
