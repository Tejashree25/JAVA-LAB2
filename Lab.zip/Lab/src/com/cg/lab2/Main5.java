package com.cg.lab2;
/*Modify the above program, to accept only �M� or �F� as gender field values. Use Enumeration for implementing the same.
 * Tejashree mahajan
 * */
public class Main5 {
	public static void main(String[] args) {
		Problem5 p1=new Problem5("Tejashree","Mahajan","8888888888");
		p1.setGender();
		p1.show();
	}
	
}
