package com.cg.lab2;
/*
 * Write a program to accept a number from user as a command line argument and check whether the given number is positive or negative number.
 * Tejashree Mahajan
 * */
public class Program2 {
	public static void main(String[] args) {
		
			int result = Integer.parseInt(args[0]);	
			if(result<0)
				System.out.println("Negative number");
			else
				System.out.println("Positive number");
	
	}

}
